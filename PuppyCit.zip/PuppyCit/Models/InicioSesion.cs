﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace PuppyCit.Models
{
    public class InicioSesion
    {
        public int IdUsuario { get; set; }
        public string Telefono { get; set; }

       
      
        public static InicioSesion ObtenerSesionActual(ISession session) //obtener la sesion actual por http
        {
            //variables para guadar el id del usuario y el teléfono de la sesión
            var usuarioId = session.GetInt32("IdUsuario");
            var telefonoStr = session.GetString("Telefono"); 

            if (!string.IsNullOrEmpty(telefonoStr))  
               // si estan vacias devuelve nullo

            {
                if (usuarioId.HasValue)
                {
                    return new InicioSesion  // si el teléfono no es nulo y el id de usuario tiene valor, devuelve los datos
                    {
                        IdUsuario = usuarioId.Value,
                        Telefono = telefonoStr 
                    };
                }
            }

            return null;
        }



            public static void IniciarSesion(InicioSesion usuario, ISession session)
            {
                // metodo para iniciar la sesión guardando los datos del usuario
                session.SetInt32("IdUsuario", usuario.IdUsuario);
                // guardo el id de usuario y el teléfono en la sesión
                session.SetString("Telefono", usuario.Telefono); 
            }
        
        }

         

}

