﻿
using System; 
using System.Data; 
using Npgsql; 
using System.Collections.Generic;
namespace PuppyCit.Models

{
    public class Conexion
    {
        public Cliente Cliente { get; set; }

        private String strConexion;
        public  Conexion()
        {
            strConexion = "Server=localhost;Username=postgres;Database=puppycit;Password=root; ";

        }
        public DataTable GetQuery(string sql)

        {
            DataTable tabla = new DataTable();

            NpgsqlDataAdapter adaptador = new NpgsqlDataAdapter();
            try
            {  // se crea una conexión a la base de datos
                using NpgsqlConnection _con = new NpgsqlConnection(strConexion);

                // se abre la conexión
                _con.ConnectionString = strConexion;
                _con.Open();
                // se prepara el comando para ejecutar la consulta
                using NpgsqlCommand comando = new NpgsqlCommand();

                comando.Connection = _con;
                comando.CommandText = sql;
                adaptador.SelectCommand = comando;
                // se asigna el comando al adaptador
                using NpgsqlDataReader lector = comando.ExecuteReader();
                // se ejecuta la consulta y se carga el resultado en la tabla
                if (lector.HasRows)
                {
                    tabla.Load(lector);
                }
                // se cierra el lector y la conexión
                lector.Close();
                _con.Close();
            }

            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);   // se imprime el error si ocurre
            }

            return tabla;


        }

        protected DataTable GetQuery(string sql, List<NpgsqlParameter> parametros)
        {

            DataTable tabla = new DataTable();

            NpgsqlDataAdapter adaptador = new NpgsqlDataAdapter();
            using (NpgsqlConnection _con = new NpgsqlConnection(strConexion))
            { // se crea la conexión y se abre
                _con.ConnectionString = strConexion;

                _con.Open();

                using (NpgsqlCommand comando = new NpgsqlCommand())
                {
                    try
                    {
                        comando.Connection = _con;
                        // se configura el comando
                        comando.CommandText = sql;
                        comando.Parameters.Clear();
                        // se agregan los parámetros al comando
                        foreach (NpgsqlParameter param in parametros)
                        {
                            comando.Parameters.Add(param);

                        }
                        adaptador.SelectCommand = comando;
                        // se asigna el comando al adaptador y se llena la tabla
                        adaptador.Fill(tabla);
                    }
                    catch (Exception e)
                    {// se imprime el error si ocurre
                        System.Console.WriteLine(e.Message);

                    }
                }

                _con.Close();
                // se cierra la conexión
            }
            return tabla;

        }

        public int ExecuteCommand(string sql, List<NpgsqlParameter> parametros)
        // este método ejecuta comandos para un valor unico, que van a devolver el id de clinica
        {
            int result = 0;  // para almacenar el resultado de la ejecución, el id clinica
            using (NpgsqlConnection _con = new NpgsqlConnection(strConexion))
            {
                _con.Open();
                using (NpgsqlCommand comando = new NpgsqlCommand(sql, _con))
                {

                    foreach (var param in parametros)
                    {
                        comando.Parameters.Add(param);
                    }

                    // ejecuta el comando y obtiene el primer valor y lo guarda en result
                    result = (int)comando.ExecuteScalar();
                }
            }
            return result; // devuelve el resultado 
        }

    } 


}
