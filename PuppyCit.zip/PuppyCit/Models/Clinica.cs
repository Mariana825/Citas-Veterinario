﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Npgsql;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace PuppyCit.Models
{
    public class Clinica : Conexion
    {
        public int IdClinica { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Estado { get; set; }
        public int Codigo_p { get; set; }
        public string Municipio { get; set; }
        public string Colonia { get; set; }
        public string Calle { get; set; }

        public Clinica() { }

        public Clinica(int idClinica)
        {
            this.IdClinica = idClinica;
        }

        public Clinica(int idClinica, string nombre, string telefono, string estado, int codigo_p,
            string municipio, string colonia, string calle)
            : this(idClinica)
        {
            Nombre = nombre;
            Telefono = telefono;
            Estado = estado;
            Codigo_p = codigo_p;
            Municipio = municipio;
            Colonia = colonia;
            Calle = calle;
        }

        public Clinica GetClinicaById(int id)
        {
            // obtiene la clínica en base al id que se seleccionó
            const string SQL = "SELECT * FROM clinica WHERE id_clinica = :id;";
            NpgsqlParameter paramId = new NpgsqlParameter(":id", id);
            // crea el parámetro y lo añade a la lista
            List<NpgsqlParameter> lstParameter = new List<NpgsqlParameter>() { paramId };
            DataTable tabla = GetQuery(SQL, lstParameter); // hace la consulta y lo guarda en la tabla

            if (tabla.Rows.Count < 1)
                return new Clinica(); // retorna vacío si no se encuentra la clínica

            foreach (DataRow row in tabla.Rows) // recorre y lo guarda en un objeto Clinica
            {
                Clinica clinica = new Clinica
                {
                    IdClinica = (int)row["id_clinica"],
                    Nombre = (string)row["nombre"],
                    Telefono = (string)row["telefono"],
                    Estado = (string)row["estado"],
                    Codigo_p = (int)row["codigo_p"],
                    Municipio = (string)row["municipio"],
                    Colonia = (string)row["colonia"],
                    Calle = (string)row["calle"]
                };

                return clinica; // devuelve la clínica encontrada
            }
            return new Clinica(); // si no encuentra nada, retorna vacío
        }


        public List<Clinica> GetClinica()
        // obtiene todas las clínicas la base de dato s se almacenan en una lista de objetos de tipo 'Clinica'.
        {
            const string sql = "SELECT * FROM clinica;";
            DataTable tabla = GetQuery(sql);
            // hace la consulta y almacenar el resultado en un DataTable.
            List<Clinica> lstClinica = new List<Clinica>(); //crea una lisat vacia de las clincas

            if (tabla.Rows.Count < 1)
            {
                return lstClinica; //sino hay devuelve una vacia
            }
            foreach (DataRow fila in tabla.Rows) //recorre todas las filas de la tabla
            {
                lstClinica.Add(new Clinica( // y crea un objeto con todos los datos
                    (int)fila["id_clinica"],
                    (string)fila["nombre"],
                    (string)fila["telefono"],
                    (string)fila["estado"],
                    (int)fila["codigo_p"],
                    (string)fila["municipio"],
                    (string)fila["colonia"],
                    (string)fila["calle"]
                    ));
            }
            return lstClinica; //regresa la lista
        }

        public int AddClinica(Clinica clinica)
        {
            //crea una clinica hace la consulta y se necesita que retorne el id de la clinica para poder usarlo en Horario LCinica

            const string sql = "INSERT INTO clinica (nombre, telefono, estado, codigo_p, municipio, colonia, calle) " +
                               "VALUES (:nom, :tel, :est, :cod, :mun, :col, :cal) RETURNING id_clinica;";

            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>();
            //crea la lista y sus parametrs
            NpgsqlParameter paramNombre = new NpgsqlParameter(":nom", clinica.Nombre);
            NpgsqlParameter paramTelefono = new NpgsqlParameter(":tel", clinica.Telefono);
            NpgsqlParameter paramEstado = new NpgsqlParameter(":est", clinica.Estado);
            NpgsqlParameter paramCodigoP = new NpgsqlParameter(":cod", clinica.Codigo_p);
            NpgsqlParameter paramMunicipio = new NpgsqlParameter(":mun", clinica.Municipio);
            NpgsqlParameter paramColonia = new NpgsqlParameter(":col", clinica.Colonia);
            NpgsqlParameter paramCalle = new NpgsqlParameter(":cal", clinica.Calle);
          
            //añade los parametros a la lista
            lstParams.Add(paramNombre);
            lstParams.Add(paramTelefono);
            lstParams.Add(paramEstado);
            lstParams.Add(paramCodigoP);
            lstParams.Add(paramMunicipio);
            lstParams.Add(paramColonia);
            lstParams.Add(paramCalle);

            //ejecutar la consulta  y obtiene el id de la clínica recién insertada.
            clinica.IdClinica = ExecuteCommand(sql, lstParams);

            // retornar el id de la clínica insertada.
            return clinica.IdClinica;
        }



        public void EditClinica(Clinica clinic)
        {
           //metodo para editar todo lo que es la parte de clinica
            const string SQL = "UPDATE clinica SET nombre = :nom, telefono = :tel, estado = :est, codigo_p = :cod, municipio = :mun, " +
                               "colonia = :col, calle = :cal " +
                               "WHERE id_clinica = :id;";
            // crea todos los parametros
            NpgsqlParameter paramId = new NpgsqlParameter(":id", clinic.IdClinica);
            NpgsqlParameter paramNombre = new NpgsqlParameter(":nom", clinic.Nombre);
            NpgsqlParameter paramTelefono = new NpgsqlParameter(":tel", clinic.Telefono);
            NpgsqlParameter paramEstado = new NpgsqlParameter(":est", clinic.Estado);
            NpgsqlParameter paramCodigoP = new NpgsqlParameter(":cod", clinic.Codigo_p);
            NpgsqlParameter paramMunicipio = new NpgsqlParameter(":mun", clinic.Municipio);
            NpgsqlParameter paramColonia = new NpgsqlParameter(":col", clinic.Colonia);
            NpgsqlParameter paramCalle = new NpgsqlParameter(":cal", clinic.Calle);

            //crea la lista y añade todos los parametros que se crearon
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>()
            {
                paramId, paramNombre, paramTelefono, paramEstado, paramCodigoP,
                paramMunicipio, paramColonia, paramCalle, 
            };
            //ejecuta la consulta
            GetQuery(SQL, lstParams);
        }


        public void AddHorarioClinica(int idClinica, string dia, TimeSpan horaApertura, TimeSpan horaCierre)
        {
            //agrega un horario en base a la clinica que se va a obtener su id recien insetada
            const string sql = "INSERT INTO horario_clinica (id_clinica, dia, hora_apertura, hora_cierre) " +
                               "VALUES (:id_clinica, :dia, :hora_a, :hora_c);";
            //crea la lista y añade los parametros a la lista
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>
                {
                    new NpgsqlParameter(":id_clinica", idClinica),
                    new NpgsqlParameter(":dia", dia),
                    new NpgsqlParameter(":hora_a", horaApertura),
                    new NpgsqlParameter(":hora_c", horaCierre)
                };
            //ejecuta la consulta
            GetQuery(sql, lstParams);
        }

        public void DeleteClinica(int id)
        {
            // Se elimina la clínica en base a su id
            const string sql = "DELETE FROM clinica WHERE id_clinica = :id;";
            NpgsqlParameter paramId = new NpgsqlParameter(":id", id);
            //cre la lista
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>();
            lstParams.Add(paramId); //agrega el parametro a la lista

            // Se ejecuta la consulta
            GetQuery(sql, lstParams);
        }

        

    }
}
