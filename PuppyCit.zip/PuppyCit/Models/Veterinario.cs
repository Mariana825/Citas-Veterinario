﻿using System.Collections.Generic;
using System.Data;
using Humanizer;
using Npgsql;

namespace PuppyCit.Models
{
    public class Veterinario : Conexion
    {
        public int IdVeterinario { get; set; }
        public string Especialidad { get; set; }
        public string Cedula { get; set; }
        public int IdUsuario { get; set; }
        public int? IdClinica {  get; set; }
        
        public Clinica Clinica { get; set; }
        public Usuario Usuario { get; set; }
        
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Telefono { get; set; }
        public Cita Cita { get; set; }
        public int IdCita { get; set; }

        public Veterinario() { }

        public Veterinario(int idVeterinario)
        {
            this.IdVeterinario = idVeterinario;
        }

        public Veterinario(int idVeterinario, string especialidad, string cedula, int idUsuario, int? idClinica)
            : this(idVeterinario)
        {
            Especialidad = especialidad;
            Cedula = cedula;
            IdUsuario = idUsuario;
            IdClinica=IdClinica;
        }

       
        public void AddVeterinario(Veterinario veterinarin)
        {
            // insertar los datos del veterinario
            const string sql = "INSERT INTO veterinario (especialidad, cedula, id_usuario, id_clinica) VALUES (:esp, :ced, :id_usu, :id_clin);";

            // lista de parámetros y la creacion de elloa
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>();

            NpgsqlParameter paramEspecialidad = new NpgsqlParameter(":esp", veterinarin.Especialidad);
            NpgsqlParameter paramCedula = new NpgsqlParameter(":ced", veterinarin.Cedula);
            NpgsqlParameter paramIdUsuario = new NpgsqlParameter(":id_usu", veterinarin.IdUsuario);

            // si IdClinica es nulo, se pone DBNull.Value para manejar correctamente los valores nulos en la base de datos
            NpgsqlParameter paramIdClinica = new NpgsqlParameter(":id_clin", (object)veterinarin.IdClinica ?? DBNull.Value);

            // agregando todos los parámetros a la lista
            lstParams.Add(paramEspecialidad);
            lstParams.Add(paramCedula);
            lstParams.Add(paramIdUsuario);
            lstParams.Add(paramIdClinica);

            // ejecutando la consulta 
            GetQuery(sql, lstParams);
        }



        public Veterinario GetVeterinarioById(int idUsuario)
        {
            // Consulta SQL para obtener los datos del veterinario, usuario y clínica donde trabje
            const string SQL = @"
                                    SELECT 
                                        veterinario.id_veterinario, 
                                        veterinario.especialidad, 
                                        veterinario.cedula, 
                                        veterinario.id_usuario, 
                                        veterinario.id_clinica, 
                                        usuario.nombre, 
                                        usuario.apellidos, 
                                        usuario.telefono, 
                                        clinica.nombre AS clinica_nombre 
                                    FROM veterinario
                                    INNER JOIN usuario ON veterinario.id_usuario = usuario.id_usuario 
                                    LEFT JOIN clinica ON veterinario.id_clinica = clinica.id_clinica  
                                    WHERE usuario.id_usuario = @idUsuario;"; 

            // crea el parametro idusuario que se necesita, y crea una lista
            NpgsqlParameter paramId = new NpgsqlParameter("@idUsuario", idUsuario);
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter> { paramId };

            // ejecuta y obtiene la tabla
            DataTable tabla = GetQuery(SQL, lstParams);

            if (tabla.Rows.Count < 1)
                return new Veterinario();// no devulve nada si no hay
            DataRow row = tabla.Rows[0]; // obtiene la primera fila de la tabla (solo hay una fila si la consulta es correcta)

            //crea un objeto de veterinairo y asigna los parametros a lo de las tablas
            Veterinario vet = new Veterinario
            {
                IdVeterinario = (int)row["id_veterinario"],  
                Especialidad = (string)row["especialidad"],
                Cedula = (string)row["cedula"],  
                IdUsuario = (int)row["id_usuario"], 
                IdClinica = row["id_clinica"] as int? 
            };

            //utiliza el objeto d evterinairo creado, oara tambien mandarle los valores de usuario y mostrarlos en el perfil
            vet.Usuario = new Usuario
            {
                Nombre = row["nombre"] as string,  
                Apellidos = row["apellidos"] as string,  
                Telefono = row["telefono"] as string,  
            };

            // realiza lo mismo pero con lcinica, recordando que el veterinario puede no tener una clinica
            vet.Clinica = new Clinica
            {
                Nombre = row["clinica_nombre"] != DBNull.Value ? (string)row["clinica_nombre"] : null  // Si hay nombre de clínica, lo asigna, si no, asigna null
            };

           //devuelve el vet
            return vet;
        }


        public void EditarDatosPersonalesv(Veterinario vet)
        {
            const string sqlUsuario = @" UPDATE usuario  SET nombre = :nombre, apellidos = :apellidos, telefono = :telefono 
            WHERE id_usuario = :idUsuario;";

            NpgsqlParameter paramNombre = new NpgsqlParameter(":nombre", vet.Usuario.Nombre);
            NpgsqlParameter paramApellidos = new NpgsqlParameter(":apellidos", vet.Usuario.Apellidos);
            NpgsqlParameter paramTelefono = new NpgsqlParameter(":telefono", vet.Usuario.Telefono);
            NpgsqlParameter paramIdUsuario = new NpgsqlParameter(":idUsuario", vet.IdUsuario);

            List<NpgsqlParameter> lstParamsUsuario = new List<NpgsqlParameter>
            {
                paramNombre, paramApellidos, paramTelefono, paramIdUsuario
            };

            GetQuery(sqlUsuario, lstParamsUsuario);
        }
        public void EditarInfo(Veterinario vet)
        {
            const string sqlVeterinario = @"UPDATE veterinario 
                                            SET especialidad = :especialidad, 
                                                cedula = :cedula, 
                                                id_clinica = :idclinica 
                                            WHERE id_usuario = :idUsuario;";

            // Definir los parámetros para la consulta SQL
            NpgsqlParameter paramEspecialidad = new NpgsqlParameter(":especialidad", vet.Especialidad);
            NpgsqlParameter paramCedula = new NpgsqlParameter(":cedula", vet.Cedula);
            NpgsqlParameter paramIdClinica = new NpgsqlParameter(":idclinica", vet.IdClinica);
            NpgsqlParameter paramIdUsuario = new NpgsqlParameter(":idUsuario", vet.IdUsuario);

            // Lista de parámetros
            List<NpgsqlParameter> lstParamsVeterinario = new List<NpgsqlParameter>
                {
                    paramEspecialidad, paramCedula, paramIdClinica, paramIdUsuario
                };

            // Ejecutar la consulta
            GetQuery(sqlVeterinario, lstParamsVeterinario);
        }




        public List<Veterinario> GetVeterinariosPorClinica(int idClinica)
        {
            //obtiene una lista de veterinario por clinica, utilizada en el fromulario de cita,
            //para que el usuario pueda escoger con que veterinario hacer su cita
            const string sql = @"SELECT veterinario.id_veterinario, usuario.nombre
                                        FROM veterinario
                                        INNER JOIN usuario ON veterinario.id_usuario = usuario.id_usuario
                                        WHERE veterinario.id_clinica = :id_clinica;";


            NpgsqlParameter paramIdClinica = new NpgsqlParameter(":id_clinica", idClinica);
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>() { paramIdClinica };
            DataTable tabla = GetQuery(sql, lstParams);
            //se crea la lista donde se va a añadir el aprametro clinica y ejecuta la consulta
            List<Veterinario> veterinarios = new List<Veterinario>(); // se crea una lista de veterianrios vacia
            foreach (DataRow row in tabla.Rows) //recorre la lista y añade todos los veterinarios en base a la clinica en una lista
            {
                veterinarios.Add(new Veterinario
                {
                    IdVeterinario = (int)row["id_veterinario"],
                    Nombre = (string)row["nombre"] 
                });
            }
            return veterinarios; //devuelve la lista de parametros
        }

        public List<Resena> GetResenas(int idVeterinario)
        {
         //metodo para obtener todas las reseñas, pero segun el id veterinario 
            const string sql = @" SELECT resena.comentario, resena.calificacion, servicio.nombre AS nombre_servicio 
                    FROM resena INNER JOIN servicio ON resena.id_servicio = servicio.id_servicio
                    WHERE resena.id_veterinario = @idVeterinario";

            var param = new NpgsqlParameter("@idVeterinario", idVeterinario); // se crean los parametros
            DataTable tabla = GetQuery(sql, new List<NpgsqlParameter> { param }); // y se ejecuta la consulta con

            List<Resena> resenas = new List<Resena>();
            //se crea una lista de las reseñas
            foreach (DataRow fila in tabla.Rows)
            {
                //recorre esa tabla obtenida y guarda los valores en un objeto de la reseña
               
                resenas.Add(new Resena
                {
                    Comentario = (string)fila["comentario"],
                    Calificacion = (int)fila["calificacion"],
                    //tambien se agrega la parte de servicio obtenido
                    Servicio = new Servicio
                    {
                        Nombre = (string)fila["nombre_servicio"]
                    }
                });
            }

            return resenas;
        }

        public List<Clinica> GetClinicasPorVeterinario(int idVeterinario)
        {
            //metodo para obtener todas la clinicas que esta asignado un  veterinario
            const string sql = @" SELECT clinica.id_clinica, clinica.nombre, clinica.telefono, clinica.estado, 
               clinica.codigo_p, clinica.municipio, clinica.colonia, clinica.calle FROM clinica
                INNER JOIN veterinario ON clinica.id_clinica = veterinario.id_clinica
                WHERE veterinario.id_veterinario = :id_veterinario;";
            // se crea un parametro de veterinario
            NpgsqlParameter paramIdVeterinario = new NpgsqlParameter(":id_veterinario", idVeterinario); //se añade dicho parametro a la lista
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>() { paramIdVeterinario };
            DataTable tabla = GetQuery(sql, lstParams); //se ejecuta al consulta y se guarda en una tabla

            List<Clinica> clinicas = new List<Clinica>(); //se crea una lista de las clinicas

            foreach (DataRow row in tabla.Rows)
            { //se recorre la tabla
                clinicas.Add(new Clinica //en dicha lista se guardan todos los valores de la clinica
                {
                    IdClinica = (int)row["id_clinica"],
                    Nombre = (string)row["nombre"],
                    Telefono = row["telefono"] as string,
                    Estado = (string)row["estado"],
                    Codigo_p = (int)row["codigo_p"],
                    Municipio = (string)row["municipio"],
                    Colonia = (string)row["colonia"],
                    Calle = (string)row["calle"]
                });
            }

            return clinicas; //retorna las clinicas
        }
        public void DeleteVeterinario(int id)
        {
            //metodo para eliminar el veterinario segun el id
            const string sql = "DELETE FROM veterinario WHERE id_veterinario = :id;";
            NpgsqlParameter paramId = new NpgsqlParameter(":id", id); //se cre un parametro
            List<NpgsqlParameter> lstParam = new List<NpgsqlParameter>() { paramId }; //se agrega dicho parametro a un lista

            GetQuery(sql, lstParam); //se ejecuta la consulta
        }
    }
}
