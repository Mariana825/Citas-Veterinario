﻿using Npgsql;
using System.Data;

namespace PuppyCit.Models
{
    public class Resena: Conexion
    {
        public int IdResena { get; set; }
        public string Comentario { get; set; }
        public int Calificacion { get; set; }
        public int IdCliente {  get; set; }
        public int IdServicio {  get; set; }
        public int IdVeterinario { get; set; }
        public Servicio Servicio { get; set; }
        public Resena() { }

        public Resena (int IdResena)
        {
            this.IdResena = IdResena;
        }
        public Resena(int idResena, string comentario, int calificacion, int idCliente, int idServicio, int idVeterinario)
    : this(idResena)
        {
            this.Comentario = comentario;
            this.Calificacion = calificacion;
            this.IdCliente = idCliente;
            this.IdServicio = idServicio;
            this.IdVeterinario = idVeterinario;
        }

        public List<Resena> GetResena()
        {
            const string sql = "SELECT * FROM resena;"; // consulta para obtener todas las reseñas
            DataTable tabla = GetQuery(sql); // ejecuta la consulta y devuelve los datos en una tabla
            List<Resena> lstResena = new List<Resena>(); // crea una lista vacia de reseñas

            if (tabla.Rows.Count < 1) // si no hay filas en la tabla, no hay reseñas
            {
                return lstResena; // devuelve una lista vacia
            }

            foreach (DataRow fila in tabla.Rows) // recorre cada fila de la tabla
            {
                // crea un nuevo objeto resena con los datos de la fila y lo agrega a la lista
                lstResena.Add(new Resena(
                    (int)fila["id_resena"],
                    (string)fila["comentario"],
                    (int)fila["calificacion"],
                    (int)fila["id_cliente"],
                    (int)fila["id_servicio"],
                    (int)fila["id_veterinario"]
                ));
            }
            return lstResena; // retorna la lista con todas las reseñas
        }



        public void AddResena(Resena resenita)
        {
            const string sql = "INSERT INTO resena (comentario, calificacion, id_cliente, id_servicio, id_veterinario) VALUES (:coment, :calif, :id_clie, :id_serv, :id_vete);";

            // la lista de parámetros
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>();

            // se crean los parámetros que van a la lista
            lstParams.Add(new NpgsqlParameter(":coment", resenita.Comentario));
            lstParams.Add(new NpgsqlParameter(":calif", resenita.Calificacion));
            lstParams.Add(new NpgsqlParameter(":id_clie", resenita.IdCliente));
            lstParams.Add(new NpgsqlParameter(":id_serv", resenita.IdServicio));
            lstParams.Add(new NpgsqlParameter(":id_vete", resenita.IdVeterinario));

            // ejecuta la consulta con los parámetros
            GetQuery(sql, lstParams);
        }


    }


}
