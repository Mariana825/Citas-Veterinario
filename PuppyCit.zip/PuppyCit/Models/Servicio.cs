﻿using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Metrics;
using Microsoft.CodeAnalysis;
using Npgsql;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace PuppyCit.Models
{
    public class Servicio : Conexion
    {
        public int IdServicio { get; set; }
        public string Nombre { get; set; }
        public string Tratamiento { get; set; }

        public decimal Costo { get; set; }
        public string Diagnostico { get; set; }
        public string MetodoPago { get; set; }
       
        public int IdCita { get; set; }
        public string Cuentapaypal { get; set; }
       


        public Servicio() { }

        public Servicio(int idServicio)
        {
            this.IdServicio = idServicio;
        }

        public Servicio(int idServicio, string nombre, string tratamiento, string diagnostico, decimal costo, string metodoPago, int idCita, string cuentapaypal)
            : this(idServicio)
        {
            Nombre = nombre;
            Tratamiento = tratamiento;
            Diagnostico = diagnostico;
            Costo = costo;
            MetodoPago = metodoPago;
            IdCita = idCita;
            Cuentapaypal = cuentapaypal;  
        }

       

        public void AddServicio(Servicio servicio)
        {
           // metodo para añadir el servicio a la base de datos
            const string sql = "INSERT INTO servicio (nombre, tratamiento, diagnostico, costo, metodo_pago, id_cita, cuentapaypal) VALUES (:nom, :trat, :diag, :cost, :metodo, :id_cita, :cuenta);";
            //se crean los parametros y la lista
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>();

            NpgsqlParameter paramNombre = new NpgsqlParameter(":nom", servicio.Nombre);
            NpgsqlParameter paramTratamiento = new NpgsqlParameter(":trat", servicio.Tratamiento);
            NpgsqlParameter paramDiagnostico = new NpgsqlParameter(":diag", servicio.Diagnostico);
            NpgsqlParameter paramCosto = new NpgsqlParameter(":cost", servicio.Costo);
            NpgsqlParameter paramMetodoPago = new NpgsqlParameter(":metodo", servicio.MetodoPago);
            NpgsqlParameter paramIdCita = new NpgsqlParameter(":id_cita", servicio.IdCita);
            NpgsqlParameter paramCuentaPaypal = new NpgsqlParameter(":cuenta", servicio.Cuentapaypal);  
            //se añaden los aprametros a la lista
            lstParams.Add(paramNombre);
            lstParams.Add(paramTratamiento);
            lstParams.Add(paramDiagnostico);
            lstParams.Add(paramCosto);
            lstParams.Add(paramMetodoPago);
            lstParams.Add(paramIdCita);
            lstParams.Add(paramCuentaPaypal);  

            GetQuery(sql, lstParams); //se ejecuta la consulta
        }

        public Servicio GetServicioById(int id)
        { //metodo para obtener el servicio por medio del id
            const string SQL = "SELECT * FROM servicio WHERE id_servicio = :id;";
            NpgsqlParameter paramId = new NpgsqlParameter(":id", id); //se crean los parametros
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter> { paramId }; //se crea la lista
            DataTable tabla = GetQuery(SQL, lstParams); //se ejecuta la consulta y se guarda en una tabla

            if (tabla.Rows.Count < 1) return new Servicio(); //si no hay, retorna vacio

            foreach (DataRow row in tabla.Rows) //recorre toda la tabla
            {
                Servicio serv = new Servicio();
                //un objeto servicio se guardan todos los atributos obtenido
                serv.IdServicio = (int)row["id_servicio"];
                serv.Nombre = (string)row["nombre"];
                serv.Tratamiento = (string)row["tratamiento"];
                serv.Diagnostico = (string)row["diagnostico"];
                serv.Costo = (decimal)row["costo"];
                serv.MetodoPago = (string)row["metodo_pago"];
                serv.IdCita = (int)row["id_cita"];
                serv.Cuentapaypal = (string)row["cuentapaypal"];  

                return serv; //retorna el objeto con todos los atributos
            }
            return new Servicio();
        }


       
        public void ActualizarEstadoCita(int idCita, string estado)
        {
         
            //  consulta SQL para actualizar el estado de la cita
            const string sql = "UPDATE cita SET estado = @estado WHERE id_cita = @idCita";

            // lista de parámetros para la consulta SQL
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>
                {
                    new NpgsqlParameter("@estado", estado), //se añaden los parametros a la lista
                    new NpgsqlParameter("@idCita", idCita)
                };

            
            GetQuery(sql, lstParams); //se ejecuta la consulta
        }
        


    }

}
