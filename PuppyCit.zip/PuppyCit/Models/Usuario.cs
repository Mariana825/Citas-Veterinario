﻿using System.Collections.Generic;
using System.Data;
using Microsoft.CodeAnalysis.Scripting;
using Npgsql;

namespace PuppyCit.Models
{
    public class Usuario : Conexion
    {
        public int IdUsuario { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Telefono { get; set; }
        public string Contraseña { get; set; }
        public int Tipo { get; set; }

        public Cliente Cliente { get; set; }
        public Veterinario Veterinario { get; set; }

        public Usuario() { }

        public Usuario(int idUsuario) // se crea otro constructor que inicializa las propiedades
        {
            this.IdUsuario = idUsuario; // se usa para diferenciar entre la propiedad de la clase y el parámetro del constructor
        }

        public Usuario(int idUsuario, string nombre, string apellidos, string telefono, string contraseña, int tipo)
            : this(idUsuario) // creamos un constructor con todos los atributos
        {
            Nombre = nombre; // cada propiedad se asigna a los parámetros del constructor
            Apellidos = apellidos; // lo mismo con apellidos
            Telefono = telefono; // lo mismo con telefono
            Contraseña = contraseña; // lo mismo con contraseña
            Tipo = tipo; // lo mismo con tipo
        }

        public List<Usuario> GetUsuario()
        {
            const string sql = "SELECT * FROM usuario;"; // extraemos todos los datos de tipo usuario
            DataTable tabla = GetQuery(sql); // la clase conexión retorna una tabla
            List<Usuario> lstUsuario = new List<Usuario>(); // mando a llamar al constructor, generando una lista

            if (tabla.Rows.Count < 1) // Verificar si la tabla está vacía
            {
                return lstUsuario; // la lista de usuarios es nula, devuelve una lista nueva vacía 
            }

            foreach (DataRow fila in tabla.Rows)
            {
                lstUsuario.Add(new Usuario( // crea un nuevo objeto Usuario a partir de los valores de la fila
                    (int)fila["id_usuario"], // convierte el valor de "id_usuario" a entero
                    (string)fila["nombre"], // convierte nombre a string
                    (string)fila["apellidos"], // convierte apellidos a string
                    (string)fila["telefono"], // convierte telefono a long
                    (string)fila["contrasena"], // convierte contraseña a string
                    (int)fila["tipo"])); // convierte tipo a entero
            }
            return lstUsuario; // Devuelve la lista de usuarios
        }

        public void AddUsuario(Usuario usuarito)
        {
            const string sql = "INSERT INTO usuario (nombre, apellidos, telefono, contrasena, tipo) VALUES (:nom, :ap, :tel, :contra, :tip) RETURNING id_usuario;";

               List < NpgsqlParameter > lstParams = new List<NpgsqlParameter>();

                lstParams.Add(new NpgsqlParameter(":nom", usuarito.Nombre));
                lstParams.Add(new NpgsqlParameter(":ap", usuarito.Apellidos));
                lstParams.Add(new NpgsqlParameter(":tel", usuarito.Telefono));
                lstParams.Add(new NpgsqlParameter(":contra", usuarito.Contraseña));
                lstParams.Add(new NpgsqlParameter(":tip", usuarito.Tipo));



            usuarito.IdUsuario = ExecuteCommand(sql, lstParams); 
           // GetQuery(sql, lstParams);

        }
    

        public Usuario GetUsuarioById(int id)
        {
            const string SQL = "SELECT * FROM usuario WHERE id_usuario = :id;"; 
            NpgsqlParameter paramId = new NpgsqlParameter(":id", id);
            List<NpgsqlParameter> lstParameter = new List<NpgsqlParameter>() { paramId };
            DataTable tabla = GetQuery(SQL, lstParameter);
            if (tabla.Rows.Count < 1) return new Usuario();

            foreach (DataRow row in tabla.Rows)
            {

                Usuario user = new Usuario();
                user.IdUsuario = (int)row["id_usuario"];
                user.Nombre = (string)row["nombre"];
                user.Apellidos = (string)row["apellidos"];
                user.Telefono = (string)row["telefono"];
                user.Contraseña = (string)row["contrasena"];
                user.Tipo = (int)row["tipo"];

                return user;
            }
            return new Usuario();
        }

       
       
         
    }
}
