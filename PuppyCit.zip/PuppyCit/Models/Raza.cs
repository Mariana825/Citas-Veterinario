﻿using System.Collections.Generic;


using System.Data;
using Npgsql;

namespace PuppyCit.Models
{
    public class Raza : Conexion
    {
      
        public int IdRaza { get; set; }
        public string Nombre { get; set; }
        
        public int IdEspecie { get; set; }
        public string EspecieNombre { get; set; }
        public Especie Especie { get; set; }

        public Raza() { }

        public Raza(int idRaza, string nombre, int idEspecie)
        {
            IdRaza = idRaza;
            Nombre = nombre;
            IdEspecie = idEspecie;
        }
        public List<Raza> GetRazas()
        {
            //metodo para obtener todas las razas
            const string sql = @" SELECT raza.id_raza, raza.nombre AS nombre_raza, especie.id_especie, especie.nombre AS nombre_especie
        FROM raza INNER JOIN especie ON raza.id_especie = especie.id_especie;  ";

            // ejecuta la consulta SQL y lo guarda en una tabla
            DataTable table = GetQuery(sql);
            List<Raza> razas = new List<Raza>();

            // recorre sobre cada fila de la tabla
            foreach (DataRow row in table.Rows)
            {
                razas.Add(new Raza
                {
                    IdRaza = (int)row["id_raza"],  // id de la raza
                    Nombre = (string)row["nombre_raza"],  // nombre de la raza
                    Especie = new Especie
                    {
                        IdEspecie = (int)row["id_especie"],  // id de la especie
                        Nombre = (string)row["nombre_especie"]  // nombre de la especie
                    }
                });
            }

            return razas;  // devuelve la lista de razas
        }
        public Raza GetRazaById(int id)
        {
            //metodo para obtener la raza por el id
            const string sql = @" SELECT raza.id_raza, raza.nombre AS nombre_raza, especie.id_especie, especie.nombre AS nombre_especie
        FROM raza
        INNER JOIN especie ON raza.id_especie = especie.id_especie
        WHERE raza.id_raza = @id; ";
            //cre el parametro y lo guarda en la lista creada
            NpgsqlParameter param = new NpgsqlParameter("@id", id);
            List<NpgsqlParameter> parameters = new List<NpgsqlParameter> { param };

            // Ejecuta la consulta SQL con el parámetro
            DataTable table = GetQuery(sql, parameters);

            if (table.Rows.Count == 0)
            {
                return null;  // Si no se encuentra la raza
            }

            // Si se encuentra la raza, devuelve los datos
            DataRow row = table.Rows[0];
            return new Raza
            {
                IdRaza = (int)row["id_raza"],
                Nombre = (string)row["nombre_raza"],  // Nombre de la raza
                Especie = new Especie
                {
                    IdEspecie = (int)row["id_especie"],  
                    Nombre = (string)row["nombre_especie"]  // Nombre de la especie
                }
            };
        }



        public List<Raza> GetRazasPorEspecie(int idEspecie)
        {
            //obtienen todas las razas en base al id especie, igul se utiliza para el formulario de mascota
            const string sql = "SELECT * FROM raza WHERE id_especie = @idEspecie;";
            //crea el parametro, crea la losta y añade
            NpgsqlParameter paramIdEspecie = new NpgsqlParameter("@idEspecie", idEspecie);
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter> { paramIdEspecie };
            //se ejecuta la consukta
            DataTable tabla = GetQuery(sql, lstParams);
            List<Raza> lstRazas = new List<Raza>();
            //se crea una lista para todas las razass
            foreach (DataRow fila in tabla.Rows) //recore las filas de la tabla y se añade a la lista
            {
                lstRazas.Add(new Raza(
                    (int)fila["id_raza"],
                    (string)fila["nombre"],
                    (int)fila["id_especie"]
                ));
            }

            return lstRazas; //retorna la lista de razas
        }

    }
}
