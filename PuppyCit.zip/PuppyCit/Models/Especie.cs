﻿
using System.Data;
using Npgsql;

namespace PuppyCit.Models
{
    public class Especie : Conexion
    {
        public int IdEspecie { get; set; }
        public string Nombre { get; set; }

        public Especie() { }

        public Especie(int idEspecie)
        {
            this.IdEspecie = idEspecie;
        }

        public Especie(int idEspecie, string nombre) : this(idEspecie)
        {
            Nombre = nombre;
        }

       
        public List<Especie> GetEspecies() //va a obtener todo un listado de las especies
                                           //y lo va a mostrar en el formulario d emascota
        {
            const string sql = "SELECT * FROM especie;";
            //hace la cosnulta y los guarda los datos en una tabla
            DataTable tabla = GetQuery(sql);
            List<Especie> lstEspecie = new List<Especie>(); // crea una lista para mostrar las espcies

            if (tabla.Rows.Count < 1)
            {
                return lstEspecie; //regresa vacio sino hay nada
            }

            foreach (DataRow fila in tabla.Rows) //recorre las filas de la tabala y agrega las especies a la lista
            {
                lstEspecie.Add(new Especie(
                    (int)fila["id_especie"],
                    (string)fila["nombre"]
                ));
            }
            return lstEspecie;
        }

      

        public Especie GetEspecieById(int id)
        {
            //obtiene la especie en base al id que se selecciono
            const string SQL = "SELECT * FROM especie WHERE id_especie = :id;";
            NpgsqlParameter paramId = new NpgsqlParameter(":id", id);
            //crea el parametro y lo añade a la lista
            List<NpgsqlParameter> lstParameter = 
                new List<NpgsqlParameter>() { paramId };
            DataTable tabla = GetQuery(SQL, lstParameter); //hace la consulta y lo guarda en la tabla

            if (tabla.Rows.Count < 1)
                return new Especie(); //retorna vacio

            foreach (DataRow row in tabla.Rows) //recorre y lo guarda en un onbjeto especie
            {
                Especie especie = new Especie
                {
                    IdEspecie = (int)row["id_especie"],
                    Nombre = (string)row["nombre"]
                };

                return especie; //devuelve la especie encontrada
            }
            return new Especie(); //no devuelve nadq
        }

    }
}
