﻿using System.Collections.Generic;

using System.Data;
using Npgsql;


namespace PuppyCit.Models
    {
        public class Mascota : Conexion
        {
            public int IdMascota { get; set; }
            public string Nombre { get; set; }
            public string Tamaño { get; set; }
            public int Edad { get; set; }

            public int IdRaza { get; set; }
            
            public int IdCliente { get; set; }
            public Especie Especie { get; set; }

        public Raza Raza { get; set; }
       

        public Mascota() { }

            public Mascota(int idMascota)
            {
                this.IdMascota = idMascota;
            }

            public Mascota(int idMascota, string nombre, string tamaño, int edad, int idRaza, int idCliente)
            : this(idMascota)
            {
                Nombre = nombre;
                Tamaño = tamaño;
                Edad = edad;
                IdRaza = idRaza;
                IdCliente = idCliente;
            }

        public Mascota GetMascotaById(int id)
        {
           //metodo para obtener la mascota por el id
            const string SQL = "SELECT * FROM mascota WHERE id_mascota = :id;";

           //crea los parametros
            NpgsqlParameter paramId = new NpgsqlParameter(":id", id);

           //crea una lista y agrega el parametro creado
            List<NpgsqlParameter> lstParameter = new List<NpgsqlParameter>() { paramId };

           //ejecuta la consulta y lo guarda en una tabla
            DataTable tabla = GetQuery(SQL, lstParameter); 

            if (tabla.Rows.Count < 1)
                return null; 
            //recorre la tabla y si es menor de 1, devuelve null
           
            Mascota mascota = new Mascota(); //crea un objeto de la clase mascota
            foreach (DataRow row in tabla.Rows)
            {//guarda todos los tributos lo de la mascota en el objeto mascota
                mascota.IdMascota = (int)row["id_mascota"];
                mascota.Nombre = (string)row["nombre"];
                mascota.Tamaño = (string)row["tamano"];
                mascota.Edad = (int)row["edad"];
                mascota.IdRaza = (int)row["id_raza"];
                mascota.IdCliente = (int)row["id_cliente"];
            }
            //retorna la mascota
            return mascota;
        }

        public void AddMascota(Mascota mascotita)
            {
            //para crear una mascota
                const string sql = "INSERT INTO mascota (nombre, tamano, edad, id_raza, id_cliente) VALUES (:nom, :tam, :edad, :raza, :cliente);";

                NpgsqlParameter paramNombre = new NpgsqlParameter(":nom", mascotita.Nombre);
                NpgsqlParameter paramTamaño = new NpgsqlParameter(":tam", mascotita.Tamaño);
                NpgsqlParameter paramEdad = new NpgsqlParameter(":edad", mascotita.Edad);
                NpgsqlParameter paramIdRaza = new NpgsqlParameter(":raza", mascotita.IdRaza);
                NpgsqlParameter paramIdCliente = new NpgsqlParameter(":cliente", mascotita.IdCliente);
            //crear parametros y la lista y ir añadiendo a la lista

            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>();
                lstParams.Add(paramNombre);
                lstParams.Add(paramTamaño);
                lstParams.Add(paramEdad);
                lstParams.Add(paramIdRaza);
                lstParams.Add(paramIdCliente);
           
            //ejecuta la consulta
            GetQuery(sql, lstParams);
            }


        public void EditMascota(Mascota mascota)
        {

            // editar la mascota según el ID seleccionado
            const string sql = "UPDATE mascota SET nombre = :nom, tamano = :tam, edad = :edad WHERE id_mascota = :id;";
            
            // crear los parámetros para la consulta
            NpgsqlParameter paramId = new NpgsqlParameter(":id", mascota.IdMascota);
            NpgsqlParameter paramNombre = new NpgsqlParameter(":nom", mascota.Nombre);
            NpgsqlParameter paramTamaño = new NpgsqlParameter(":tam", mascota.Tamaño);
            NpgsqlParameter paramEdad = new NpgsqlParameter(":edad", mascota.Edad);

            // crear la lista de parámetros
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>();

            // cgregar los parámetros a la lista
            lstParams.Add(paramId);
            lstParams.Add(paramNombre);
            lstParams.Add(paramTamaño);
            lstParams.Add(paramEdad);

            // ejecutar la consulta con los parámetros
            GetQuery(sql, lstParams);
        }


        public void DeleteMascota(int id)
            {
            //se elimina la mascota en base a su id
                const string sql = "DELETE FROM mascota WHERE id_mascota = :id;";
                NpgsqlParameter paramId = new NpgsqlParameter(":id", id);
            //cre los parametros y la lista
                List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>();
                lstParams.Add(paramId);
            // se ejucuta la consulta
                GetQuery(sql, lstParams);
            }
        public List<Mascota> GetMascotasPorCliente(int idCliente)
        {
            // se crea una lista de las mscotas del ccleinte que se va a utilizar en el formulario de cita,
            // donde va a escoger que mascota llevar al vet
            const string sql = @" SELECT mascota.id_mascota,  mascota.nombre,  mascota.edad, 
                                           raza.nombre AS raza,  especie.nombre AS especie
                                    FROM mascota
                                    INNER JOIN raza ON mascota.id_raza = raza.id_raza
                                    INNER JOIN especie ON raza.id_especie = especie.id_especie
                                    WHERE mascota.id_cliente = :id_cliente;";
            // se hace la consulta en abse al id cliente
            NpgsqlParameter paramIdCliente = new NpgsqlParameter(":id_cliente", idCliente);
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>() { paramIdCliente };
            // se crea la lista y se añade el parametro
            DataTable tabla = GetQuery(sql, lstParams); //ejecuta la consulta

            List<Mascota> mascotas = new List<Mascota>(); // va a crear una lista de mascotas, que es loq ue se va a mostrar
            foreach (DataRow row in tabla.Rows)
            {
                mascotas.Add(new Mascota // se crea el objeto mascota
                {
                    IdMascota = (int)row["id_mascota"],
                    Nombre = (string)row["nombre"],
                    Edad = (int)row["edad"],
                    Raza = new Raza
                    {
                        Nombre = (string)row["raza"] // asigna el nombre de la raza
                    },
                    Especie = new Especie
                    {
                        Nombre = (string)row["especie"] // asigna el nombre de la especie
                    }
                });
            }
            return mascotas; //retorna la mascota
        }


    }
}


