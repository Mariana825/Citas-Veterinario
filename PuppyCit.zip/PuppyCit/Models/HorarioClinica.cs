﻿using Npgsql;
using System.Data;

namespace PuppyCit.Models
{
    public class HorarioClinica: Conexion
    {
        public string Dia { get; set; }
        public TimeSpan HoraApertura { get; set; }
        public TimeSpan HoraCierre { get; set; }

        public HorarioClinica(string dia, TimeSpan horaApertura, TimeSpan horaCierre)
        {
            Dia = dia;
            HoraApertura = horaApertura;
            HoraCierre = horaCierre;
        }
        public HorarioClinica() { }
        //metodo para obtener el horario de la clinicas
        public List<HorarioClinica> GetHorarioPorClinica(int idClinica)
        {
            const string sql = "SELECT dia, hora_apertura, hora_cierre FROM horario_clinica WHERE id_clinica = :id_clinica ORDER BY dia;";
            //crea una lista para añadir los parametros
            List<NpgsqlParameter> lstParams = new List<NpgsqlParameter>
                {
                    new NpgsqlParameter(":id_clinica", idClinica)
                };

            DataTable tabla = GetQuery(sql, lstParams); // ejecuta y obtiene los horarios de la base de datos

            List<HorarioClinica> horarios = new List<HorarioClinica>(); //crea una lista para los horarios de la clinica

            if (tabla.Rows.Count > 0)
            {// recorre la tabla
                foreach (DataRow fila in tabla.Rows)
                {
                    string dia = fila["dia"].ToString();
                    TimeSpan horaApertura = (TimeSpan)fila["hora_apertura"];
                    TimeSpan horaCierre = (TimeSpan)fila["hora_cierre"];

                    horarios.Add(new HorarioClinica(dia, horaApertura, horaCierre)); // agregar el horario a la lista
                }
            }

            return horarios; // Devolver la lista de horarios
        }

    }

}
